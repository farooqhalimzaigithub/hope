<?php

namespace App\Http\Controllers;

use App\Models\RegistrationTarrif;
use Illuminate\Http\Request;

class RegistrationTarrifController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\RegistrationTarrif  $registrationTarrif
     * @return \Illuminate\Http\Response
     */
    public function show(RegistrationTarrif $registrationTarrif)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\RegistrationTarrif  $registrationTarrif
     * @return \Illuminate\Http\Response
     */
    public function edit(RegistrationTarrif $registrationTarrif)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\RegistrationTarrif  $registrationTarrif
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RegistrationTarrif $registrationTarrif)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\RegistrationTarrif  $registrationTarrif
     * @return \Illuminate\Http\Response
     */
    public function destroy(RegistrationTarrif $registrationTarrif)
    {
        //
    }
}
