<?php

namespace App\Http\Controllers;

use App\Models\ClassTarrif;
use Illuminate\Http\Request;

class ClassTarrifController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ClassTarrif  $classTarrif
     * @return \Illuminate\Http\Response
     */
    public function show(ClassTarrif $classTarrif)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ClassTarrif  $classTarrif
     * @return \Illuminate\Http\Response
     */
    public function edit(ClassTarrif $classTarrif)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ClassTarrif  $classTarrif
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ClassTarrif $classTarrif)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ClassTarrif  $classTarrif
     * @return \Illuminate\Http\Response
     */
    public function destroy(ClassTarrif $classTarrif)
    {
        //
    }
}
